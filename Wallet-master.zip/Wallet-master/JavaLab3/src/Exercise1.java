import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {

	
	
	public static int getSecondSmallest(int a[]) {
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		return a[1];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner s=new Scanner(System.in);
			System.out.println("Enter lenght of array");
			int len=s.nextInt();
			
			int [] arr= new int[len];
			System.out.println("Enter elements of array");
			for(int i=0;i<len;i++) {
				if(s.hasNextInt()) {
					arr[i]=s.nextInt();
				}
			}
			System.out.println("Element you Entered:- ");
			
			for(int i=0;i<len;i++) {
				System.out.println(arr[i]);
			}
			int a=getSecondSmallest(arr);
			System.out.println("Second smallest :- "+a);
	}

}

import java.util.Scanner;

public class Exercise2 {

	public static void sortString(String a[]) {
		String temp;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i].compareTo(a[j])>0) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
			if(a.length/2==0) {
			for(int i=0;i<a.length/2;i++) {
				a[i].toUpperCase();
			}
			for(int i=a.length/2;i<a.length;i++) {
				a[i].toLowerCase();
			}
			
		}else{
			for(int i=0;i<=a.length/2;i++) {
				a[i].toUpperCase();
			}for(int i=a.length/2+1;i<a.length;i++) {
				a[i].toLowerCase();
			}
		}
		System.out.print("Strings in Sorted Order:");
        for (int i = 0; i <=a.length - 1; i++) 
        {
            System.out.print(a[i] + ", ");
        }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		
		
		System.out.println("Enter lenght of array");
		int len=Integer.parseInt(s.nextLine());
		String[] arr=new String[len];
		System.out.println("Enter string array");
		for(int i=0;i<len;i++) {
			arr[i]=s.nextLine();
			}
		sortString(arr);
		
		
		}

	}



import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.*;
public class Exercise3 {
	 /* function that reverses array and stores it  
    in another array*/
 static void reverse(int a[], int n) 
 { 
     int[] b = new int[n]; 
     int j = n; 
     for (int i = 0; i < n; i++) { 
         b[j - 1] = a[i]; 
         j = j - 1; 
     } 

     /*printing the reversed array*/
     System.out.println("Reversed array is: \n"); 
     for (int k = 0; k < n; k++) { 
         System.out.println(b[k]); 
     }
     sort(b);
 } 
 public static void sort(int a[]) {
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		  System.out.println("Sorted array is: \n"); 
		     for (int k = 0; k < a.length; k++) { 
		         System.out.println(a[k]); 
		     }
		
	}

 public static void main(String[] args) 
 { 
	 Scanner s=new Scanner(System.in);
		System.out.println("Enter lenght of array");
		int len=s.nextInt();
		
		int [] arr= new int[len];
		System.out.println("Enter elements of array");
		for(int i=0;i<len;i++) {
			if(s.hasNextInt()) {
				arr[i]=s.nextInt();
			}
		}
		System.out.println("Element you Entered:- ");
		
		for(int i=0;i<len;i++) {
			System.out.println(arr[i]);
		}
		
		reverse(arr, arr.length);
	        

 } 
}
package com.cg.service;
import java.util.Map;


import com.cg.bean.*;
import com.cg.dao.*;

import com.cg.exception.InsuffecientFundException;

public class AccountService implements Gst,Transaction {
	
	AccountDAO dao=new AccountDAOImpl();

	@Override
	public double withdraw(Account ob, double amount) throws InsuffecientFundException {
		double new_balance=ob.getBalance()-amount;
		if(new_balance<1000.0)
		{
			new_balance=ob.getBalance();
			//System.out.println("Insufficient balance");
			//throw new RuntimeException("Insufficient Fund. It will effect minium balance");
			throw new InsuffecientFundException("Insufficient Fund. It will effect minium balance",new_balance);
		}
		ob.setBalance(new_balance);
		dao.updateAccount(ob);
		return new_balance;
	}

	@Override
	public double deposite(Account ob, double amount) {
		// TODO Auto-generated method stub
		double new_balance=0.0;
		if(amount>0) {
			 new_balance=ob.getBalance()+amount;
		}
		ob.setBalance(new_balance);
		dao.updateAccount(ob);
		return new_balance;
	}

	

	@Override
	public double calculateTax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*Gst.PCT_5;
	}

	@Override
	public boolean addAccount(Account ob) {
		// TODO Auto-generated method stub\
		
		return dao.addAccount(ob);
	}
	

	@Override
	public boolean deleteAccount(Account ob) {
		// TODO Auto-generated method stub
		return dao.deleteAccount(ob);
	}

	@Override
	public Account findAccount(Long Mobileno) {
		// TODO Auto-generated method stub
		return dao.findAccount(Mobileno);
	}

	@Override
	public Map<Long, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return dao.getAllAccount();
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		return dao.updateAccount(ob);
	}

	@Override
	public double TransferMoney(Account from, Account to, double amount) throws InsuffecientFundException {
		// TODO Auto-generated method stub
		return dao.TransferMoney(from, to, amount);
	}
	
	
	

}

package com.cg.dao;

import java.util.*;

import com.cg.bean.Account;
import com.cg.exception.InsuffecientFundException;

public class AccountDAOImpl implements AccountDAO {
	
	static Map<Long, Account> accamp=new HashMap<Long,Account>();

	@Override
	public boolean addAccount(Account ob) {
		// TODO Auto-generated method stub
		accamp.put(ob.getMobile(), ob);
		if(accamp!=null)
		{
			return true;
		}
		else {
			return false;
		}
		
		
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		accamp.put(ob.getMobile(), ob);
		return true;
	}

	@Override
	public boolean deleteAccount(Account ob) {
		accamp.remove(ob);
		
		return true;
	}

	@Override
	public Account findAccount(Long Mobileno) {
		// TODO Auto-generated method stub
		Account ob=accamp.get(Mobileno);
		
		return ob;
	}

	

	@Override
	public Map<Long, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accamp;
	}

	@Override
	public double TransferMoney(Account from, Account to, double amount) throws InsuffecientFundException {
		// TODO Auto-generated method stub
		double new_balance=from.getBalance()-amount;
		double new_balance1=to.getBalance()+amount;
		if(new_balance<1000.0 && amount>0)
		{
			new_balance=from.getBalance();
			new_balance1=to.getBalance();
			
			throw new InsuffecientFundException("Insufficient fund. Can not be transfered",amount);
		}
		from.setBalance(new_balance);
		to.setBalance(new_balance1);
		AccountDAOImpl dao = new AccountDAOImpl();
		dao.updateAccount(from);
		dao.updateAccount(to);
		return new_balance;
	}

	@Override
	public boolean transferMoney(Account from, Account to) {
		// TODO Auto-generated method stub
		return false;
	}
}

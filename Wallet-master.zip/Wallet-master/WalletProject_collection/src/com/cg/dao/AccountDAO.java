package com.cg.dao;

import com.cg.bean.*;
import com.cg.exception.InsuffecientFundException;

import java.util.*;

public interface AccountDAO {
	
	public boolean addAccount(Account ob);
	
	public boolean updateAccount(Account ob);
	
	public boolean deleteAccount(Account ob);
	
	public Account findAccount(Long Mobileno);
	
	public boolean transferMoney(Account from, Account to);
	
	public Map<Long,Account> getAllAccount();
	public double TransferMoney(Account from, Account to,double amount) throws InsuffecientFundException;
	
	

}

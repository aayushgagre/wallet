package com.cg.eis.service;

import java.util.Map;


import com.cg.eis.bean.Employee;
import com.cg.eis.dao.*;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO dao = new EmployeeDAOImpl();
	@Override
	public boolean addEmployee(Employee e) {
		// TODO Auto-generated method stub
		return dao.addEmployee(e);
	}

	@Override
	public Map<Integer, Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public String getScheme(int e_id, double salary, String e_designation) {
		// TODO Auto-generated method stub
		if(((salary>=5000)&&(salary<20000))&&(e_designation.equalsIgnoreCase("System Associate")))
		{
	     return "Scheme C";
		}
else if(((salary>=20000)&&(salary<40000))&&(e_designation.equalsIgnoreCase("Programmer")))
{
 return "Scheme B";
}

else if((salary>=40000)&&(e_designation.equalsIgnoreCase("Manager")))
{
 return "Scheme A";
}

else if((salary<5000)&&(e_designation.equalsIgnoreCase("Clerk")))
{
 return "No Scheme";
}

else 
{
 return "Invalid Details";
}
	}
}

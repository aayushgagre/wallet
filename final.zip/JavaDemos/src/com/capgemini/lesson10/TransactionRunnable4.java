package com.capgemini.lesson10;

public class TransactionRunnable4 implements Runnable {

	int balance=1000;
	boolean valueSet=false;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String option = Thread.currentThread().getName();
		for(int i=1;i<=10;i++)
		{
			if(option=="Sham")
				deposite(1000);
			if(option.equals("Ram"))
				printBalance();
				
		}
		
	}

	private synchronized void printBalance() {
		
		if(!valueSet)
		{
			try{
				wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
		else
		{
		System.out.println("Thread ::" +Thread.currentThread().getName());
		System.out.println("Balance" + balance);
		valueSet=true;
		notify();
		}
	}

	private synchronized void deposite(int amount) {
		// TODO Auto-generated method stub
		
		if(!valueSet)
		{
			try{
				wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
		System.out.println("Thread in deposite :::" + Thread.currentThread().getName());
		System.out.println("Before deposite " + balance);
		balance=balance+amount;
		System.out.println("After deposite " + balance);
		System.out.println("Thread ended :::" + Thread.currentThread().getName());
		valueSet=false;
		notify();
		}
	}
}

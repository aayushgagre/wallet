 package com.capgemini.lesson10;

import com.capgemini.lesson10.runnable.MyRunnable;

public class ThreadJoinDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        TransactionRunnable3 m=new TransactionRunnable3();
		Thread producer = new Thread(m, "Sham");
        Thread consumer = new Thread(m, "Ram");
        
         
        producer.start();
        consumer.start();
        
        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException exp) {
           System.err.println(exp.getMessage());
        }
         
        System.out.println("All threads are dead, exiting main thread");
	}

}

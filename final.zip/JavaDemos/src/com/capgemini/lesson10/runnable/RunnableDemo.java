package com.capgemini.lesson10.runnable;

import java.util.Date;

public class RunnableDemo {
	
	
	public static void main(String[] args) {
		

		MyRunnable ob=new MyRunnable();
		Thread t1=new Thread(ob,"Ram");
		Thread t2=new Thread(ob,"Sham");
		
		t1.start();
		t2.start();
		/*Thread fstThread = new Thread(new MyRunnable());
		
		
		fstThread.start();
		
	*/
			
			
	
	}

}

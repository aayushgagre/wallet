 package com.capgemini.lesson10;



public class ThreadJoinDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        TransactionRunnable4 m=new TransactionRunnable4();
		Thread producer = new Thread(m, "Sham");
        Thread consumer = new Thread(m, "Ram");
        
         
        producer.start();
        consumer.start();
        
        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException exp) {
           System.err.println(exp.getMessage());
        }
         
        System.out.println("All threads are dead, exiting main thread");
	}

}

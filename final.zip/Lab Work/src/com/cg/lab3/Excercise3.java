package com.cg.lab3;

import java.util.Scanner;

public class Excercise3 {

	public static void main(String s[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of an array");
		int n=sc.nextInt();
		System.out.println("Enter the elements in an array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		
		int b[]=getSorted(a,n);
		System.out.println("Sorted array");
		for(int i=0;i<n;i++)
			System.out.println(a[i]);
	}

	static int[] getSorted(int a[], int n) 
    { 
        int k,t; 
        for (int i=0;i<n/2;i++) { 
            t=a[i]; 
            a[i]=a[n-i-1]; 
            a[n-i-1]=t; 
        } 
        
        for (int i=0;i<n;++i) 
        {
            for (int j=i+1;j<n;++j)
            {
                if (a[i]>a[j]) 
                {
                    int x=a[i];
                    a[i]=a[j];
                    a[j] = x;
                }
            }
        }
        return a;
    }
}

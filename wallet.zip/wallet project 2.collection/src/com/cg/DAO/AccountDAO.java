package com.cg.DAO;

import java.util.Map;

import com.cg.bean.Account;

public interface AccountDAO {
	
	public boolean addAccount(Account ob);//success
	
	
	public boolean deleteAccount(Account ob);//success
	public Account findAccount(Long mobileno);//success
	public Map<Long,Account> getAllAccounts();

	

}

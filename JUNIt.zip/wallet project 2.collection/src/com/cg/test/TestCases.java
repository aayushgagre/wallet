package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;
import com.cg.service.AccountService;

public class TestCases {

	static AccountService service=new AccountService();
	
	@Test
	public void testAddAccount()
	{
		Account ob=new Account(100,9719832969l,"Aayush Gagre",10000.00);
		assertTrue(service.addAccount(ob));
		System.out.println("Add Account test case1 run successfully");
		
		
		Account ob2=new Account(10103,76543210l,"Keshav Sharma",-1000);
		Assumptions.assumeFalse(service.addAccount(ob2));
		System.out.println("Add Account test case2 run successfully");
		
		Account ob3=new Account(10103,76543210l,null,-1000);
		assertThrows(NullPointerException.class,()->service.addAccount(ob3));
		System.out.println("Add Account test case3 run successfully");
	}
	
	@Test
	public void testDeposite()
	{
		Account ob=new Account(100,9719832969l,"Aayush Gagre",10000.00);
		assertTrue(service.deposite(ob, 10000)>0.0);
		System.out.println("Deposite test case1 run successfully");
	}

	@Test
	public void transferTest()
	{
		Account ob=new Account(100,9719832969l,"Aayush Gagre",10000.00);
		Account ob1=new Account(101,9876543210l,"Rupen Jain",20000.00);
		
		assertEquals(true,service.transferMoney(ob, ob1, 5000));
		System.out.println("Transfer test case1 run successfully");

		assertEquals(true,service.transferMoney(ob, ob1, -5000));
		System.out.println("Transfer test case2 run successfully");

	}
	
	public void withdrawTest() throws InsufficientFundException
	{
		Account ob=new Account(100,9719832969l,"Aayush Gagre",10000.00);
		assertEquals(true,service.withdraw(ob, 20000));
		
		System.out.println("Withdraw Test case run successfully");
		
		assertEquals(true,service.withdraw(ob, 500));
		System.out.println("Withdraw Test case1 run successfully");

	}
}

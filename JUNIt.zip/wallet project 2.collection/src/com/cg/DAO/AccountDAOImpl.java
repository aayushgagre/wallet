package com.cg.DAO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO{

	static Map<Long, Account> accmap=new HashMap<Long, Account>();
	
	public boolean addAccount(Account ob)
	{
		accmap.put(ob.getMobile(), ob);
		return true;
	}

	@Override
	public boolean deleteAccount(Account ob) {
		// TODO Auto-generated method stub
		accmap.remove(ob.getMobile());
		return true;
	}

	@Override
	public Account findAccount(Long mobileno) {
		// TODO Auto-generated method stub
		Account ob=accmap.get(mobileno);
		return ob;
	}

	@Override
	public Map<Long, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		
		Collection<Account> vc=accmap.values();
		List<Account> acclist=new ArrayList<Account>(vc);
		//Collections.sort(acclist);
		for(Account o:acclist)
			System.out.println(o);
		return accmap;
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		 long mobile=ob.getMobile();
	        accmap.put(mobile, ob);
			

		return true;
	}

}
